format pliku dla obstacles.txt:


{
	Ilo�� przeszk�d do wczytania
	
	Ilo�� wierzcho�k�w pierwszej przeszkody
	x0 y0
	x1 y1
	x2 y2
	.
	.
	.

	Ilo�� wierzcho�k�w drugiej przeszkody
	x0 y0
	x1 y1
	.
	.
	.

	.
	.
	.
}


zmiana pliku background.png zmienia t�o (niesamowite)